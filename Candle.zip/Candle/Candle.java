import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;



public class Candle {
  
  public static List<Double> oneyeardata(String inpdate,String readcsvpath){
    
    List<Double> finaldata = new ArrayList<Double>();
    List<String> date = new ArrayList<String>();
    List<String> data = new ArrayList<String>();

    try{ 
      BufferedReader csvfile =new BufferedReader(new FileReader(readcsvpath));
      String line = " ";
      String everyline = " ";
      double num_of_date = 0;
      double current_date = 0;
      List<Double> high = new ArrayList<Double>();
      List<Double> low  = new ArrayList<Double>();
      
      
      
      double open = 0;
      double close = 0;
      double highest = 0;
      double lowest = 0;
      
  
      while((line = csvfile.readLine())!=null){
        everyline = line;
        data.add(everyline);
        date.add(everyline.split(",")[0]);     
        }
      
      num_of_date = date.size();
      current_date = date.indexOf(inpdate);

      if(date.contains(inpdate))
      {
        if(date.size()-date.indexOf(inpdate)<365)
        {
          for(int i=date.indexOf(inpdate);i<(date.size());i++)
          {
            if(data.get(i).contains("null"))
            {
              continue;
            }
            else
            {
              high.add(Double.parseDouble(data.get(i).split(",")[2]));
              low.add(Double.parseDouble(data.get(i).split(",")[3]));
              close = Double.parseDouble(data.get(data.size()-1).split(",")[4]);
            }
          }
          highest = Collections.max(high);
          lowest  = Collections.min(low);
          
          for(int i=date.indexOf(inpdate);i<(date.size());i++)
          {
            if(data.get(i).contains("null"))
            {
              continue;
            }
            else
            {
              open = Double.parseDouble(data.get(i).split(",")[1]);
              break;
            }
          }
          
          finaldata.add(open);
          finaldata.add(highest);
          finaldata.add(lowest);
          finaldata.add(close);
          finaldata.add(current_date);
          finaldata.add(num_of_date);
        }

        else
        {
          for(int i=date.indexOf(inpdate);i<(date.indexOf(inpdate)+365);i++)
          {
           if(data.get(i).contains("null"))
            {
              continue;
            }
            else
            {
              high.add(Double.parseDouble(data.get(i).split(",")[2]));
              low.add(Double.parseDouble(data.get(i).split(",")[3]));
              for(int j=date.indexOf(inpdate)+365;;j++){
                if(!data.get(j).contains("null")){
                  close = Double.parseDouble(data.get(j).split(",")[4]);
                  break;
                }
                
              }
              
            }
          }
          highest = Collections.max(high);
          lowest  = Collections.min(low);
          
          for(int i=date.indexOf(inpdate);i<(date.size());i++)
          {
            if(data.get(i).contains("null"))
            {
              continue;
            }
            else
            {
              open = Double.parseDouble(data.get(i).split(",")[1]);
              break;
            }
          }
          
          finaldata.add(open);
          finaldata.add(highest);
          finaldata.add(lowest);
          finaldata.add(close);
          finaldata.add(current_date);
          finaldata.add(num_of_date);
        }
      }
      else
      {
        System.out.println("输入的日期不存在");
      }
      
      // 测试代码
      // int i=date.indexOf(inpdate)+365;
      // System.out.println(date.get(i));
      // System.out.println(data.get(i));

      csvfile.close();
      }catch(IOException e){
        System.out.println("文件读写出错");
      }

    
    return finaldata;
  }


  static void stick(List<Double>finaldata,int i){
    double x_pos = i+1;
    
    StdDraw.setPenColor(new java.awt.Color(finaldata.get(0)<finaldata.get(3)?0xff882244:0xff228844));
    StdDraw.line(x_pos,finaldata.get(0),x_pos,finaldata.get(3));
    StdDraw.filledRectangle(x_pos,(finaldata.get(1)+finaldata.get(2))/2, 0.5 , Math.abs(finaldata.get(1)-finaldata.get(2))/2);
  }


  static List<String> date_list(String readcsvpath){
    
    List<String> date = new ArrayList<String>();
    List<String> data = new ArrayList<String>();
    try{
      
      BufferedReader csvfile =new BufferedReader(new FileReader(readcsvpath));
      String line = " ";
      String everyline = " ";
    
      while((line = csvfile.readLine())!=null){
        everyline = line;
        data.add(everyline);
        date.add(everyline.split(",")[0]);     
        }
      
      csvfile.close();


    }catch(IOException e){
      System.out.println("文件读写出错");
    }
      
    return date;
        

  }

  public static void main(String[] args) {

    Scanner scanner = new Scanner(System.in);
    String readcsvpath ="D:\\ProgramProject\\JAVA\\Candle\\HSI.csv";
    System.out.println("请输入初始日期(格式:xxxx年/xx月/xx日):");
    String inpdate = scanner.nextLine();
    StdDraw.setXscale(0,Math.ceil((date_list(readcsvpath).size()-date_list(readcsvpath).indexOf(inpdate))/365)+3);
    StdDraw.setYscale(500,50000);
    StdDraw.setPenRadius(0.01);
    //double small_double = 1;
    


    if(date_list(readcsvpath).contains(inpdate)){
      // System.out.println(Math.ceil((date_list(readcsvpath).size()-date_list(readcsvpath).indexOf(inpdate))/365));
      
      // System.out.println(date_list(readcsvpath).indexOf(inpdate));
      // small_double = (date_list(readcsvpath).size()-date_list(readcsvpath).indexOf(inpdate))/365;
      // System.out.println(Math.ceil(small_double));
      
      for(int i=0;i<Math.ceil((date_list(readcsvpath).size()-date_list(readcsvpath).indexOf(inpdate))/365)+1;i++){

        if(date_list(readcsvpath).contains(date_list(readcsvpath).get(date_list(readcsvpath).indexOf(inpdate)+((i-1)*365)+365))) {
          stick(oneyeardata(date_list(readcsvpath).get(date_list(readcsvpath).indexOf(inpdate)+((i-1)*365)+365), readcsvpath), i);
          System.out.println(oneyeardata(date_list(readcsvpath).get(date_list(readcsvpath).indexOf(inpdate)+((i-1)*365)+365), readcsvpath));
          continue;
        }
        if(date_list(readcsvpath).contains(date_list(readcsvpath).get(date_list(readcsvpath).indexOf(inpdate)+((i-1)*365)+366))){
          stick(oneyeardata(date_list(readcsvpath).get(date_list(readcsvpath).indexOf(inpdate)+((i-1)*365)+366), readcsvpath), i);
          continue;
        }
        if(date_list(readcsvpath).contains(date_list(readcsvpath).get(date_list(readcsvpath).indexOf(inpdate)+((i-1)*365)+367))){
          stick(oneyeardata(date_list(readcsvpath).get(date_list(readcsvpath).indexOf(inpdate)+((i-1)*365)+367), readcsvpath), i);
          continue;
        }
        if(date_list(readcsvpath).contains(date_list(readcsvpath).get(date_list(readcsvpath).indexOf(inpdate)+((i-1)*365)+368))){
          stick(oneyeardata(date_list(readcsvpath).get(date_list(readcsvpath).indexOf(inpdate)+((i-1)*365)+368), readcsvpath), i);
          continue;
        } 
        }
      }
      else{
      System.out.println("您输入的日期不存在与数据库中，请重新输入");
    }  
            
            // if(date_list(readcsvpath).size()-date_list(readcsvpath).indexOf(inpdate)<0){
            //   //if(date_list(readcsvpath).size()-(date_list(readcsvpath).indexOf(inpdate)+i*365)>0){
            //   stick(oneyeardata(inpdate, readcsvpath), i);
            //   System.out.println(oneyeardata(inpdate, readcsvpath));

            //   break;
            // }
            // else{
            //   if(date_list(readcsvpath).size()-(date_list(readcsvpath).indexOf(inpdate)+(i*365))>0){
            //     stick(oneyeardata(date_list(readcsvpath).get(date_list(readcsvpath).indexOf(inpdate)+(i*365)), readcsvpath), i);
            //     System.out.println((oneyeardata(date_list(readcsvpath).get((date_list(readcsvpath).indexOf(inpdate)+i*365)),readcsvpath)));
            //   }
            //   else{
            //     stick(oneyeardata(date_list(readcsvpath).get(date_list(readcsvpath).indexOf(inpdate)+((i-1)*365)), readcsvpath), i);
            //     System.out.println((oneyeardata(date_list(readcsvpath).get((date_list(readcsvpath).indexOf(inpdate)+i*365)),readcsvpath)));
            //   }
            // }
            //stick((oneyeardata(date_list(readcsvpath).get((date_list(readcsvpath).indexOf(inpdate)+i*365)),readcsvpath)), i);
            //System.out.println((oneyeardata(date_list(readcsvpath).get((date_list(readcsvpath).indexOf(inpdate)+i*365)),readcsvpath)));
      
  scanner.close();
  }
    
}
    

  // System.out.println(Math.ceil((date_list(readcsvpath).size())));
  // System.out.println(Math.ceil(date_list(readcsvpath).indexOf(inpdate)));
  

