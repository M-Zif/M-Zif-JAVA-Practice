import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Candlestick
{

  public static void main(String[] args) {
    String readcsvpath = "D:\\ProgramProject\\JAVA\\Candle\\HSI.csv";
    String writecsvpath = "D:\\ProgramProject\\JAVA\\Candle\\NewData.csv";
    Scanner scanner = new Scanner(System.in);
    System.out.println("请输入初始日期(格式:年/月/日):");
    String inpdate = scanner.nextLine();
    
    
    try{ 
    BufferedReader csvfile =new BufferedReader(new FileReader(readcsvpath));
    BufferedWriter writeText = new BufferedWriter(new FileWriter(writecsvpath),1000000000);
    String line = " ";
    String everyline = " ";
    List<Double> high = new ArrayList<Double>();
    List<Double> low  = new ArrayList<Double>();
    List<String> date = new ArrayList<String>();
    List<String> data = new ArrayList<String>();
    double open = 0;
    double close = 0;


    while((line = csvfile.readLine())!=null){
      everyline = line;
      data.add(everyline);
      date.add(everyline.split(",")[0]);     
      }
    
  
    if(date.contains(inpdate))
    {
      if(date.size()-date.indexOf(inpdate)<365)
      {
        for(int i=date.indexOf(inpdate);i<(date.size());i++)
        {
          if(data.get(i).contains("null"))
          {
            continue;
          }
          else
          {
            high.add(Double.parseDouble(data.get(i).split(",")[2]));
            low.add(Double.parseDouble(data.get(i).split(",")[3]));
            if(i == data.size()-1){
              close = Double.parseDouble(data.get(i).split(",")[4]);
            }
          }
        }

        for(int i=date.indexOf(inpdate);i<(date.size());i++)
        {
          if(data.get(i).contains("null"))
          {
            continue;
          }
          else
          {
            open = Double.parseDouble(data.get(i).split(",")[1]);
            break;
          }
        }

        System.out.println(Collections.max(high));
        System.out.println(Collections.min(low));
        System.out.println(open);
        System.out.println(close);
      }
      else
      {
        for(int i=date.indexOf(inpdate);i<(date.indexOf(inpdate)+366);i++)
        {
         if(data.get(i).contains("null"))
          {
            continue;
          }
          else
          {
            high.add(Double.parseDouble(data.get(i).split(",")[2]));
            low.add(Double.parseDouble(data.get(i).split(",")[3]));
            if(i == date.indexOf(inpdate)+365){
              close = Double.parseDouble(data.get(i).split(",")[4]);
            }
          }
        }

        for(int i=date.indexOf(inpdate);i<(date.size());i++)
        {
          if(data.get(i).contains("null"))
          {
            continue;
          }
          else
          {
            open = Double.parseDouble(data.get(i).split(",")[1]);
            break;
          }
        }
        System.out.println(Collections.max(high));
        System.out.println(Collections.min(low));
        System.out.println(open);
        System.out.println(close);
      }
    }
    else
    {
      System.out.println("输入的日期不存在");
    }
    
  

    writeText.flush();
    writeText.close();
    csvfile.close();
    scanner.close();
    }catch(IOException e){
      System.out.println("文件读写出错");
    }
    
   
    
    }
    

}
