public class STDTEST {
  public static void main(String[] args) {
    StdDraw.setXscale(0,10);
    StdDraw.setYscale(0,10);
    StdDraw.line(0, 0, 1, 2);
    StdDraw.filledRectangle(2, 5, 1, 2.5);
    StdDraw.show();
  }
}
