

public class CandleTest
{
  static double step(double y){
    return y+(Math.random()-0.5)*0.05;
  }
  static double minmax(int n,double y,double a[]){
    a[1]=Math.max(a[1],y);
    a[2]=Math.max(a[2],y);
    return n>1?minmax(n-1, step(y), a):y; //这种表达是什么意思
  }
  static void stick(double x,double w,double a[]){
    StdDraw.setPenColor(new java.awt.Color(a[3]<a[0]?0xff882244:0xff228844));
    StdDraw.line(x,a[1],x,a[2]);
    StdDraw.filledRectangle(x, (a[0]+a[3])/2, w , Math.abs(a[0]-a[3])/2);
  }
  
  public static void main(String[] args) {
    int n=20;
    double w=0.4/n;
    StdDraw.setPenRadius(w/2);
    double y=0.5;
    for(int i=0;i<n;i++){
      double a[]={y,y,y,y};
      a[3] = minmax(5, step(a[0]), a);
      y = step(a[3]);
      stick(w+i/(double)n,w,a);
    }
  }


}